"""Atlas4D Python SDK - Simple client for Atlas4D API"""

from .client import Client

__version__ = "0.1.0"
__all__ = ["Client"]
